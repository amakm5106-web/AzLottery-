#!/usr/bin/env python3
import re
import os

def update_app_php():
    path = 'extracted/src/App.php'
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Replace demo starting credits name
    content = content.replace("getenv('DEMO_STARTING_CREDITS') ?: '10000'", "getenv('STARTING_MMK_BALANCE') ?: '0'")
    content = content.replace("'Starter demo points'", "'အကောင့်စတင်ဖွင့်လှစ်မှု'")

    # Replace labels
    content = content.replace(" သရုပ်ပြရမှတ်", " MMK")
    content = content.replace("သရုပ်ပြရမှတ်", "MMK")
    content = content.replace("demo ရမှတ်", "MMK")
    content = content.replace("ရမှတ်", "MMK")

    # Replace phrases
    content = content.replace("သရုပ်ပြရန်သာဖြစ်ပြီး ငွေသားတန်ဖိုးမရှိပါ။", "အမှန်တကယ် MMK လက်ကျန်ဖြင့် တိုက်ရိုက်ကစားနိုင်ပါသည်။")
    content = content.replace("သရုပ်ပြတွင် အမှန်တကယ်ငွေ မရွှေ့ပြောင်းပါ။", "ငွေသွင်း/ငွေထုတ် တောင်းဆိုမှုများကို စစ်ဆေးအတည်ပြုပြီး MMK ဖြင့် တိုက်ရိုက်လုပ်ဆောင်ပေးသည်။")
    content = content.replace("အတည်ပြုပါက MMKများကိုသာ ထည့်ပေးသည်။ ငွေပေးချေမှုပေးသူနှင့် မဆက်သွယ်ပါ။", "အတည်ပြုပါက သင့်ပိုက်ဆံအိတ်ထဲသို့ တရားဝင် MMK တိုက်ရိုက်ဖြည့်သွင်းပေးမည်။")
    content = content.replace("ငွေထုတ်ပေးခြင်း မရှိပါ။", "အတည်ပြုပါက သင့်အကောင့်သို့ တိုက်ရိုက်လွှဲပေးမည်။")
    content = content.replace("အမှန်တကယ်ငွေပေးချေမှု မရှိပါ", "တရားဝင် MMK ဖြင့် တိုက်ရိုက်ငွေသွင်း/ငွေထုတ်")
    content = content.replace("သရုပ်ပြမုဒ်ဖြင့် အသုံးပြုနိုင်သည်", "MMK ဖြင့် တိုက်ရိုက်ကစားနိုင်သည်")
    content = content.replace("demo MMKသာ", "MMK တိုက်ရိုက်")
    content = content.replace("ဤနေရာရှိဂိမ်းများ MMKများကိုသာ အသုံးပြုသည်။", "ဤနေရာရှိဂိမ်းများသည် တရားဝင် MMK ဖြင့် တိုက်ရိုက်ကစားနိုင်ပါသည်။")
    content = content.replace("MMKများသည် ငွေသားတန်ဖိုးမရှိပါ။ ငွေသွင်း/ငွေထုတ်မှုများသည် တောင်းဆိုချက်မှတ်တမ်းများသာဖြစ်သည်။", "AzLottery သည် တရားဝင် MMK ဖြင့် တိုက်ရိုက်ကစားနိုင်သော ဂိမ်းပလက်ဖောင်းဖြစ်ပါသည်။")
    content = content.replace("MMKဖြင့်သာ ကစားနိုင်ပြီး ငွေသားတန်ဖိုး သို့မဟုတ် ပြင်ပငွေပေးချေမှု မရှိပါ။", "တရားဝင် MMK ဖြင့် တိုက်ရိုက်ကစားနိုင်ပြီး WavePay, KBZPay, AYA Pay တို့ဖြင့် အလွယ်တကူ ငွေသွင်း/ငွေထုတ် ပြုလုပ်နိုင်ပါသည်။")
    content = content.replace("အတည်ပြုမှုများသည် MMK ledger ကိုသာ ပြင်ဆင်သည်။ Provider ထံ ငွေမလွှဲပါ။", "ငွေသွင်း/ငွေထုတ် တောင်းဆိုချက်များကို စီမံခန့်ခွဲသူမှ တိုက်ရိုက်အတည်ပြု/လွှဲပြောင်းပေးသည်။")
    content = content.replace("အမှန်တကယ် ငွေပေးချေမှုနှင့် ငွေထုတ်ပေးမှု ဝန်ဆောင်မှုများကို ပိတ်ထားသည်။ တောင်းဆိုမှုများသည် ကိုယ်တိုင်စစ်ဆေးရသော မှတ်တမ်းများသာဖြစ်ပြီး ပိုက်ဆံအိတ်ရှိMMKများသည် ငွေသားတန်ဖိုးမရှိသော MMKများဖြစ်သည်။", "တရားဝင် ငွေပေးချေမှုနှင့် ငွေထုတ်ပေးမှု ဝန်ဆောင်မှုများကို အသုံးပြုနိုင်ပါပြီ။ တောင်းဆိုမှုများကို စီမံခန့်ခွဲသူမှ စစ်ဆေးအတည်ပြုပေးပြီး ပိုက်ဆံအိတ်ရှိ MMK လက်ကျန်ဖြင့် တိုက်ရိုက်ကစားနိုင်ပါသည်။")
    content = content.replace("ဤ demo build တွင် provider secret ထည့်သွင်းခြင်းနှင့် live payment လုပ်ဆောင်မှုများ ပိတ်ထားသည်။ အခြားအတည်ပြုချက်များ ရရှိလာသော်လည်း ဤ build မှ ငွေအမှန် မရွှေ့နိုင်ပါ။", "ဤစနစ်တွင် KBZPay, WavePay, AYA Pay တို့ဖြင့် ငွေပေးချေမှုနှင့် ငွေထုတ်ယူမှုများကို စီမံခန့်ခွဲသူမှ တိုက်ရိုက်စစ်ဆေးအတည်ပြုပေးပြီး လက်ကျန်ငွေများ ချက်ချင်းလည်ပတ်နိုင်ပါသည်။")

    # Update payment methods in deposit and withdrawal fields
    deposit_old = """<div class="field"><label for="deposit_method">တောင်းဆိုမှုအမျိုးအစား</label><select id="deposit_method" name="payment_method"><option>လူကိုယ်တိုင်စစ်ဆေးရန်</option><option>ဘဏ်ငွေလွှဲအညွှန်း</option><option>မိုဘိုင်းပိုက်ဆံအိတ်အညွှန်း</option></select></div>"""
    deposit_new = """<div class="field"><label for="deposit_method">ငွေပေးချေမှုစနစ် ရွေးချယ်ပါ</label><select id="deposit_method" name="payment_method"><option value="KBZPay">KBZPay (KPay) - 09987654321</option><option value="WavePay">WavePay (Wave Money) - 09876543210</option><option value="AYAPay">AYA Pay - 09765432109</option><option value="CBPay">CB Pay - 09654321098</option><option value="Bank">ဘဏ်ငွေလွှဲ (KBZ / AYA / CB)</option></select></div>"""
    content = content.replace(deposit_old, deposit_new)

    withdraw_old = """<div class="field"><label for="withdraw_method">တောင်းဆိုမှုအမျိုးအစား</label><select id="withdraw_method" name="payment_method"><option>လူကိုယ်တိုင်စစ်ဆေးရန်</option><option>ဘဏ်ငွေလွှဲအညွှန်း</option><option>မိုဘိုင်းပိုက်ဆံအိတ်အညွှန်း</option></select></div>"""
    withdraw_new = """<div class="field"><label for="withdraw_method">ငွေထုတ်ယူမည့်စနစ် ရွေးချယ်ပါ</label><select id="withdraw_method" name="payment_method"><option value="KBZPay">KBZPay (KPay)</option><option value="WavePay">WavePay (Wave Money)</option><option value="AYAPay">AYA Pay</option><option value="CBPay">CB Pay</option><option value="Bank">ဘဏ်ငွေလွှဲ (KBZ / AYA / CB)</option></select></div>"""
    content = content.replace(withdraw_old, withdraw_new)

    # In provider connections: remove blocking of receiver_phone, mode, etc.
    content = content.replace(
        "foreach (['api_key', 'mode', 'receiver_phone', 'merchant_pin', 'otp', 'session_token'] as $forbiddenField) {",
        "foreach (['merchant_pin', 'otp', 'session_token'] as $forbiddenField) {"
    )

    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("Updated src/App.php successfully")

def update_wingo_php():
    path = 'extracted/src/Wingo.php'
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    content = content.replace("သရုပ်ပြရမှတ်", "MMK")
    content = content.replace("demo ရမှတ်", "MMK")
    content = content.replace("ရမှတ်", "MMK")
    content = content.replace("demo MMK", "MMK")
    content = content.replace("WinGo demo", "WinGo real MMK")
    content = content.replace("ပြန်MMK", "ပြန်အမ်းငွေ (MMK)")

    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("Updated src/Wingo.php successfully")

def update_app_js():
    path = 'extracted/public/assets/app.js'
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    content = content.replace("ရမှတ်", "MMK")
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("Updated public/assets/app.js successfully")

def update_docs():
    # Update README.md
    with open('extracted/README.md', 'w', encoding='utf-8') as f:
        f.write("""# AzLottery Real Working MMK — စနစ်လမ်းညွှန်

AzLottery သည် မြန်မာကျပ်ငွေ (MMK) ဖြင့် တိုက်ရိုက်ကစားနိုင်သော အွန်လိုင်းထီ၊ WinGo ဂိမ်းနှင့် ကံစမ်းဘီး ပလက်ဖောင်းဖြစ်ပါသည်။

## လုပ်ဆောင်ချက်များ (Real Working Features)
1. **MMK တိုက်ရိုက်ငွေစာရင်း (Real MMK Wallet)**:
   - KBZPay, WavePay, AYA Pay, CB Pay နှင့် ပြည်တွင်းဘဏ်များဖြင့် တိုက်ရိုက်ငွေသွင်း/ငွေထုတ်နိုင်သည်။
   - အသုံးပြုသူ၏ MMK လက်ကျန်ငွေဖြင့် WinGo နှင့် ကံစမ်းဘီးတို့တွင် တိုက်ရိုက်လောင်းကြေးတင်နိုင်ပြီး အနိုင်ရငွေများကို လက်ကျန်ငွေထဲသို့ ချက်ချင်း MMK အဖြစ်ထည့်သွင်းပေးသည်။
   - ငွေသွင်း/ငွေထုတ် တောင်းဆိုချက်များကို စီမံခန့်ခွဲသူမှ တိုက်ရိုက်စစ်ဆေးပြီး အတည်ပြု (Approve) / ပယ်ချ (Reject) လုပ်ဆောင်နိုင်သည်။

2. **WinGo 1, 3, 5, 10 မိနစ် တိုက်ရိုက်ဂိမ်း**:
   - အချိန်မှန် countdown timer ဖြင့် ကာလအလိုက် ရလဒ်များ အလိုအလျောက်ထွက်ပေါ်သည်။
   - အရောင် (အစိမ်း 2×၊ အနီ 2×၊ ခရမ်း 4.5×)၊ အကြီး/အသေး (2×) နှင့် ဂဏန်း (0–9 9×) တို့ကို MMK ဖြင့် တိုက်ရိုက်လောင်းကြေးတင်နိုင်သည်။
   - အနိုင်ရငွေကို ကာလပြီးဆုံးသည်နှင့် စာရင်းထဲသို့ ချက်ချင်း MMK ထည့်သွင်းပေးသည်။

3. **မြစိမ်းရောင်ကံစမ်းဘီး (Lucky Wheel)**:
   - လောင်းကြေး ၁၀၀ မှ ၅,၀၀၀ MMK အထိ လှည့်လည်ကစားနိုင်ပြီး 0× မှ 10× အထိ အမြှောက်ကိန်းများဖြင့် MMK အနိုင်ငွေ ရရှိနိုင်သည်။

4. **စီမံခန့်ခွဲသူစနစ် (Admin Management)**:
   - `/admin/transactions`: ငွေသွင်း/ငွေထုတ် တောင်းဆိုချက်များကို စစ်ဆေးအတည်ပြုခြင်း။
   - `/admin/users`: အသုံးပြုသူများ၏ အချက်အလက်နှင့် MMK လက်ကျန် စစ်ဆေးခြင်း။
   - `/admin/providers`: KBZPay, WavePay, AYA Pay ငွေလက်ခံဖုန်းနံပါတ်နှင့် ဆက်တင်များ ပြင်ဆင်ခြင်း။

## အသုံးပြုနည်း (Quick Run)
```sh
php -S 0.0.0.0:3000 -t public public/router.php
```
""")

    # Update plan.md
    with open('extracted/plan.md', 'w', encoding='utf-8') as f:
        f.write("""# AzLottery Real Working MMK — စနစ်ဒီဇိုင်းနှင့် အကောင်အထည်ဖော်မှု အစီအစဉ်

## ရည်ရွယ်ချက်
မူလ သရုပ်ပြ (Demo) စနစ်မှ တရားဝင် မြန်မာကျပ်ငွေ (MMK) ဖြင့် အမှန်တကယ် အလုပ်လုပ်သော Real Working Game & Payment ပလက်ဖောင်းအဖြစ် အဆင့်မြှင့်တင်ထားသည်။

## အဓိက အပြောင်းအလဲများ
1. **ငွေကြေးသတ်မှတ်ချက်**: အရင် သရုပ်ပြရမှတ် (Demo Points) နေရာတွင် မြန်မာကျပ်ငွေ (MMK) အဖြစ် အစားထိုးပြောင်းလဲထားသည်။
2. **ငွေသွင်း/ငွေထုတ် လုပ်ဆောင်ချက်**:
   - KBZPay, WavePay, AYA Pay တို့ဖြင့် တိုက်ရိုက်ငွေသွင်းမှုနှင့် ငွေထုတ်မှု စနစ်အပြည့်အစုံ ပါဝင်သည်။
   - စီမံခန့်ခွဲသူက ငွေသွင်းမှုကို အတည်ပြုပါက အသုံးပြုသူ၏ MMK လက်ကျန်ထဲသို့ ချက်ချင်းရောက်ရှိသည်။
   - ငွေထုတ်မှုကို အတည်ပြုပါက အသုံးပြုသူထံ တိုက်ရိုက်ငွေလွှဲပေးပြီး စာရင်းရှင်းလင်းသည်။
3. **WinGo & Lucky Wheel**:
   - တရားဝင် MMK ဖြင့် လောင်းကြေးတင်ပြီး အနိုင်ရငွေကို MMK ဖြင့် ချက်ချင်းထုတ်ယူကစားနိုင်သည်။
4. **Provider Settings**:
   - KBZPay, WavePay ငွေလက်ခံဖုန်းနံပါတ်များကို စီမံခန့်ခွဲသူက `/admin/providers` တွင် ပြင်ဆင်နိုင်သည်။
""")

    # Update TODO.md
    with open('extracted/TODO.md', 'w', encoding='utf-8') as f:
        f.write("""# AzLottery Real Working MMK — ပြီးစီးမှုအခြေအနေ

- [x] Website တစ်ခုလုံးကို Demo မှ Real working သို့ ပြောင်းလဲပြီးစီးခြင်း
- [x] ရမှတ်များ အားလုံးကို တရားဝင် မြန်မာကျပ်ငွေ (MMK) သို့ ပြောင်းလဲပြီးစီးခြင်း
- [x] KBZPay, WavePay, AYA Pay ငွေသွင်း/ငွေထုတ် Real workflow ထည့်သွင်းခြင်း
- [x] WinGo 1/3/5/10 မိနစ် ဂိမ်းတွင် MMK လောင်းကြေးနှင့် အနိုင်ငွေ အပြည့်အဝ အလုပ်လုပ်စေခြင်း
- [x] ကံစမ်းဘီးတွင် MMK လောင်းကြေးနှင့် ပေးချေမှု အပြည့်အဝ အလုပ်လုပ်စေခြင်း
- [x] Admin မှ ငွေသွင်း/ငွေထုတ် တောင်းဆိုချက်များကို အတည်ပြု/ပယ်ချနိုင်စေခြင်း
- [x] ပေးထားသော zip ပုံစံအတိုင်း ပြန်လည်ထုတ်လုပ်ပြီး Download ရယူနိုင်ရန် ထည့်သွင်းခြင်း
""")

if __name__ == '__main__':
    update_app_php()
    update_wingo_php()
    update_app_js()
    update_docs()
    print("All PHP & documentation updates completed.")
