import mysql, { type Pool } from 'mysql2/promise';

declare global {
  // Reuse one connection pool across Next.js hot reloads in development.
  var azLotteryDbPool: Pool | undefined;
}

export function getAuthDb(): Pool {
  const uri = process.env.DATABASE_URL;
  if (!uri) {
    throw new Error('DATABASE_URL is not configured for the authentication service.');
  }

  if (!globalThis.azLotteryDbPool) {
    globalThis.azLotteryDbPool = mysql.createPool({
      uri,
      connectionLimit: 10,
      waitForConnections: true,
      queueLimit: 0,
      timezone: 'Z',
      enableKeepAlive: true,
    });
  }

  return globalThis.azLotteryDbPool;
}
