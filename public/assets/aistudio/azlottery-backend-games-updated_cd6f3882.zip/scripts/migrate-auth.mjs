import { readFile, readdir } from 'node:fs/promises';
import mysql from 'mysql2/promise';

const uri = process.env.DATABASE_URL;
if (!uri) {
  console.error('DATABASE_URL is not available. Run this script in the configured project environment.');
  process.exit(1);
}

const migrationDir = new URL('../migrations/', import.meta.url);
const files = (await readdir(migrationDir)).filter((file) => /^\d+_.+\.sql$/.test(file)).sort();
const statements = [];
for (const file of files) {
  const sql = await readFile(new URL(file, migrationDir), 'utf8');
  for (const statement of sql.split(/;\s*(?:\r?\n|$)/).map((value) => value.trim()).filter(Boolean)) {
    statements.push({ file, statement });
  }
}
const connection = await mysql.createConnection({ uri, timezone: 'Z' });

try {
  for (const { statement } of statements) {
    await connection.query(statement);
  }
  console.log(`AzLottery schema is ready (${files.join(', ')}; ${statements.length} additive statements).`);
} finally {
  await connection.end();
}
