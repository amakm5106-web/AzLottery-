'use client';

import React, { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Header } from '@/components/Header';
import { MobileNav } from '@/components/MobileNav';
import { HomeView } from '@/components/HomeView';
import { GamesView } from '@/components/GamesView';
import { WinGoView } from '@/components/WinGoView';
import { WheelView } from '@/components/WheelView';
import { WalletView } from '@/components/WalletView';
import { TransactionsView } from '@/components/TransactionsView';
import { AdminView } from '@/components/AdminView';
import { AccountView } from '@/components/AccountView';
import { PromotionView } from '@/components/PromotionView';
import { LotteryVariantView } from '@/components/LotteryVariantView';

export default function AzLotteryApp() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [walletLandingTab, setWalletLandingTab] = useState<'deposit' | 'withdraw'>('deposit');

  const {
    isLoaded,
    currentUser,
    users,
    transactions,
    requests,
    providers,
    gatewayWallets,
    isAutoWithdrawEnabled,
    isAutoDepositCheckEnabled,
    wingoBets,
    wingoHistory,
    wheelHistory,
    resetBalanceToZero,
    createDepositWithCheck,
    createWithdrawalWithAutoDisburse,
    approveRequest,
    rejectRequest,
    spinWheel,
    placeWinGoBet,
    settleWinGoRound,
    updateProvider,
    toggleAutoWithdraw,
    toggleAutoDepositCheck,
  } = useAppStore();

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-[#f7f8ff] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-[#4782ff] border-t-transparent rounded-full animate-spin"></div>
          <span className="text-[#4782ff] font-bold text-sm">ဖွင့်လှစ်နေပါသည်…</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#f7f8ff] text-[#1e2637]">
      {/* The game view has its own compact header and navigation. */}
      {currentTab !== 'wingo' && currentTab !== 'k3' && currentTab !== '5d' && currentTab !== 'trx' && currentTab !== 'account' && (
        <Header
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          currentUser={currentUser}
        />
      )}

      {/* Main Content Area */}
      <main className={`flex-1 ${['wingo', 'k3', '5d', 'trx'].includes(currentTab) ? 'w-full px-0 sm:wrap py-0 sm:py-6' : currentTab === 'account' ? 'w-full px-0 py-0' : 'wrap py-8 sm:py-10'}`}>
        {currentTab === 'home' && (
          <HomeView
            currentUser={currentUser}
            onNavigate={setCurrentTab}
          />
        )}

        {currentTab === 'games' && (
          <GamesView
            currentUser={currentUser}
            onNavigate={setCurrentTab}
          />
        )}

        {currentTab === 'wingo' && (
          <WinGoView
            currentUser={currentUser}
            wingoBets={wingoBets}
            wingoHistory={wingoHistory}
            onPlaceBet={placeWinGoBet}
            onSettleRound={settleWinGoRound}
            onNavigate={setCurrentTab}
          />
        )}

        {(currentTab === 'k3' || currentTab === '5d' || currentTab === 'trx') && (
          <LotteryVariantView
            variant={currentTab}
            currentUser={currentUser}
            onNavigate={setCurrentTab}
          />
        )}

        {currentTab === 'wheel' && (
          <WheelView
            currentUser={currentUser}
            wheelHistory={wheelHistory}
            onSpin={spinWheel}
            onNavigate={setCurrentTab}
          />
        )}

        {currentTab === 'account' && (
          <AccountView
            currentUser={currentUser}
            onNavigate={setCurrentTab}
            onWalletShortcut={(tab) => { setWalletLandingTab(tab); setCurrentTab('wallet'); }}
          />
        )}

        {currentTab === 'promotion' && <PromotionView onNavigate={setCurrentTab} />}

        {currentTab === 'wallet' && (
          <WalletView
            currentUser={currentUser}
            initialTab={walletLandingTab}
            requests={requests}
            providers={providers}
            gatewayWallets={gatewayWallets}
            isAutoWithdrawEnabled={isAutoWithdrawEnabled}
            isAutoDepositCheckEnabled={isAutoDepositCheckEnabled}
            onResetBalanceToZero={resetBalanceToZero}
            onCreateDeposit={createDepositWithCheck}
            onCreateWithdrawal={createWithdrawalWithAutoDisburse}
          />
        )}

        {currentTab === 'transactions' && (
          <TransactionsView
            currentUser={currentUser}
            transactions={transactions}
          />
        )}

        {currentTab === 'admin' && (
          <AdminView
            currentUser={currentUser}
            users={users}
            requests={requests}
            providers={providers}
            gatewayWallets={gatewayWallets}
            isAutoWithdrawEnabled={isAutoWithdrawEnabled}
            isAutoDepositCheckEnabled={isAutoDepositCheckEnabled}
            onApproveRequest={approveRequest}
            onRejectRequest={rejectRequest}
            onUpdateProvider={updateProvider}
            onToggleAutoWithdraw={toggleAutoWithdraw}
            onToggleAutoDepositCheck={toggleAutoDepositCheck}
          />
        )}
      </main>

      {/* Footer */}
      <footer className={`footer border-t border-slate-200 bg-white py-5 text-center text-xs text-slate-500 ${['wingo', 'k3', '5d', 'trx', 'account'].includes(currentTab) ? 'hidden' : ''}`}>
        <div className="wrap flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-[#4782ff] text-sm">AzLottery</span>
            <span className="text-slate-400 font-medium">· အွန်လိုင်းဂိမ်းဝန်ဆောင်မှု</span>
          </div>

          <div className="text-[11px] text-slate-400">
            © {new Date().getFullYear()} AzLottery. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Mobile Navigation Bar */}
      {!['wingo', 'k3', '5d', 'trx'].includes(currentTab) && (
        <MobileNav
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          currentUser={currentUser}
        />
      )}

    </div>
  );
}
