'use client';

import React, { useState } from 'react';
import type { User, PaymentRequest, ProviderConnection, GatewayWallet } from '@/lib/store';
import {
  ShieldCheck,
  Check,
  X,
  Users,
  Settings,
  CreditCard,
  AlertCircle,
  CheckCircle2,
  Phone,
  RefreshCw,
  Zap,
  FileCheck2,
  Building2,
  Send,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';

interface AdminViewProps {
  currentUser: User;
  users: User[];
  requests: PaymentRequest[];
  providers: ProviderConnection[];
  gatewayWallets: Record<string, GatewayWallet>;
  isAutoWithdrawEnabled: boolean;
  isAutoDepositCheckEnabled: boolean;
  onApproveRequest: (requestId: number, adminNote?: string) => void;
  onRejectRequest: (requestId: number, reason?: string) => void;
  onUpdateProvider: (
    code: string,
    receiverPhone: string,
    receiverName: string,
    status: 'active' | 'disabled'
  ) => void;
  onToggleAutoWithdraw: (enabled: boolean) => void;
  onToggleAutoDepositCheck: (enabled: boolean) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  currentUser,
  users,
  requests,
  providers,
  gatewayWallets,
  isAutoWithdrawEnabled,
  isAutoDepositCheckEnabled,
  onApproveRequest,
  onRejectRequest,
  onUpdateProvider,
  onToggleAutoWithdraw,
  onToggleAutoDepositCheck,
}) => {
  const [adminTab, setAdminTab] = useState<'requests' | 'gateway' | 'users' | 'providers' | 'settings'>('requests');
  const [editingProvider, setEditingProvider] = useState<ProviderConnection | null>(null);
  const [adminNote, setAdminNote] = useState<string>('');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const pendingRequests = requests.filter((r) => r.status === 'pending');
  const allRequests = requests;

  const handleApprove = (reqId: number) => {
    onApproveRequest(reqId, adminNote || 'စစ်ဆေးအတည်ပြုပြီးပါပြီ');
    setAdminNote('');
    setActionNotice(`တောင်းဆိုမှု #${reqId} ကို အတည်ပြုပေးပြီး လက်ကျန်ငွေ ဖြည့်သွင်း/လွှဲပြောင်းပေးလိုက်ပါပြီ။`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleReject = (reqId: number) => {
    onRejectRequest(reqId, adminNote || 'အချက်အလက် မကိုက်ညီပါ');
    setAdminNote('');
    setActionNotice(`တောင်းဆိုမှု #${reqId} ကို ပယ်ချလိုက်ပါပြီ။`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleSaveProvider = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProvider) return;
    onUpdateProvider(
      editingProvider.code,
      editingProvider.receiver_phone,
      editingProvider.receiver_name,
      editingProvider.status
    );
    setActionNotice(`${editingProvider.name} ဆက်တင်များကို အောင်မြင်စွာ ပြင်ဆင်ပြီးပါပြီ။`);
    setEditingProvider(null);
    setTimeout(() => setActionNotice(null), 4000);
  };

  return (
    <div className="space-y-8 animate-in fade-in">
      <div className="section-head">
        <div>
          <span className="eyebrow text-amber-400">AzLottery စီမံခန့်ခွဲသူ ထိန်းချုပ်ခန်း (Admin Panel)</span>
          <h1 className="text-3xl font-extrabold text-white">စီမံခန့်ခွဲမှု ဒက်ရှ်ဘုတ်</h1>
          <p className="text-sm text-slate-300">
            Deposit check နှင့် Auto-Withdrawal အပိုင်းများကို စီမံခန့်ခွဲခြင်း၊ ငွေသွင်း/ငွေထုတ် တောင်းဆိုချက်များ စစ်ဆေးအတည်ပြုခြင်း။
          </p>
        </div>
        <div className="admin-tag text-sm py-1 px-3">
          <ShieldCheck className="w-4 h-4 mr-1 inline" /> အထူးစီမံခန့်ခွဲသူ
        </div>
      </div>

      {/* Admin Action Notification */}
      {actionNotice && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/30 rounded-xl text-emerald-300 text-sm flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Gateway Master Switches Card */}
      <section className="p-5 rounded-2xl bg-gradient-to-r from-[#0c2619] to-[#0a1f14] border border-emerald-500/30 space-y-4 shadow-lg">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
              <Zap className="w-5 h-5 fill-amber-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Decr-main Auto Payment Engine အခြေအနေ</h2>
              <p className="text-xs text-slate-300">
                Deposit Check (ပြေစာ/TXN စစ်ဆေးမှု) နှင့် Auto-Withdrawal (အလိုအလျောက် ငွေလွှဲထုတ်ပေးမှု)
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {/* Auto-Withdraw Switch */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <strong className="text-white text-sm">Auto-Withdraw (အလိုအလျောက်ငွေထုတ်)</strong>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${isAutoWithdrawEnabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>
                  {isAutoWithdrawEnabled ? 'ဖွင့်ထားသည်' : 'ပိတ်ထားသည်'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                အသုံးပြုသူ ငွေထုတ်ယူပါက Gateway Wallet မှ စက္ကန့်ပိုင်းအတွင်း အလိုအလျောက် ငွေလွှဲထုတ်ပေးသည်။
              </p>
            </div>
            <button
              onClick={() => onToggleAutoWithdraw(!isAutoWithdrawEnabled)}
              className={`button small ${isAutoWithdrawEnabled ? 'bg-emerald-500 text-black font-extrabold' : 'secondary text-slate-400'}`}
            >
              {isAutoWithdrawEnabled ? 'ပိတ်မည်' : 'ဖွင့်မည်'}
            </button>
          </div>

          {/* Auto Deposit Check Switch */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <strong className="text-white text-sm">Deposit Check (ပြေစာစစ်ဆေးမှု)</strong>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${isAutoDepositCheckEnabled ? 'bg-blue-500/20 text-blue-300' : 'bg-red-500/20 text-red-300'}`}>
                  {isAutoDepositCheckEnabled ? 'ဖွင့်ထားသည်' : 'ပိတ်ထားသည်'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                WavePay/KBZPay ပြေစာနှင့် TXN ID ကို အလိုအလျောက်စစ်ဆေးပြီး အောင်မြင်ပါက MMK ချက်ချင်းဖြည့်သွင်းသည်။
              </p>
            </div>
            <button
              onClick={() => onToggleAutoDepositCheck(!isAutoDepositCheckEnabled)}
              className={`button small ${isAutoDepositCheckEnabled ? 'bg-blue-500 text-white font-extrabold' : 'secondary text-slate-400'}`}
            >
              {isAutoDepositCheckEnabled ? 'ပိတ်မည်' : 'ဖွင့်မည်'}
            </button>
          </div>
        </div>
      </section>

      {/* Admin Subtabs */}
      <div className="inline-actions">
        <button
          onClick={() => setAdminTab('requests')}
          className={`button small ${adminTab === 'requests' ? '' : 'secondary'}`}
        >
          ငွေလွှဲတောင်းဆိုချက်များ ({pendingRequests.length} ဆိုင်းငံ့)
        </button>
        <button
          onClick={() => setAdminTab('gateway')}
          className={`button small ${adminTab === 'gateway' ? '' : 'secondary'}`}
        >
          <Building2 className="w-3.5 h-3.5 mr-1 inline" /> Gateway Vault များ
        </button>
        <button
          onClick={() => setAdminTab('users')}
          className={`button small ${adminTab === 'users' ? '' : 'secondary'}`}
        >
          <Users className="w-3.5 h-3.5 mr-1 inline" /> အသုံးပြုသူများ ({users.length})
        </button>
        <button
          onClick={() => setAdminTab('providers')}
          className={`button small ${adminTab === 'providers' ? '' : 'secondary'}`}
        >
          <CreditCard className="w-3.5 h-3.5 mr-1 inline" /> Provider ဆက်တင်များ
        </button>
        <button
          onClick={() => setAdminTab('settings')}
          className={`button small ${adminTab === 'settings' ? '' : 'secondary'}`}
        >
          <Settings className="w-3.5 h-3.5 mr-1 inline" /> စနစ်ဆက်တင်များ
        </button>
      </div>

      {/* Tab 1: Payment Requests */}
      {adminTab === 'requests' && (
        <section className="panel wide border-emerald-500/25 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
            <div>
              <h2 className="text-xl font-bold text-white">ငွေသွင်း/ငွေထုတ် တောင်းဆိုချက်များ စစ်ဆေးခြင်း</h2>
              <p className="text-xs text-slate-300">
                Deposit Check စနစ်ဖြင့် အလိုအလျောက် စိစစ်ပြီးစီးမှုများနှင့် Auto-Withdraw ငွေလွှဲမှတ်တမ်းများ။
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              ဆိုင်းငံ့တောင်းဆိုမှု: {pendingRequests.length} ခု
            </span>
          </div>

          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>အမှတ်စဉ်</th>
                  <th>အသုံးပြုသူ</th>
                  <th>အမျိုးအစား</th>
                  <th>ပမာဏ (MMK)</th>
                  <th>စနစ်</th>
                  <th>TXN ID / အကောင့်</th>
                  <th>လုပ်ဆောင်မှု</th>
                  <th>အခြေအနေ</th>
                  <th>ရက်စွဲ</th>
                  <th>လုပ်ဆောင်ချက်</th>
                </tr>
              </thead>
              <tbody>
                {allRequests.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="text-center py-8 text-slate-400">
                      ငွေလွှဲတောင်းဆိုချက် မရှိသေးပါ။
                    </td>
                  </tr>
                ) : (
                  allRequests.map((req) => (
                    <tr key={req.id}>
                      <td className="font-mono text-xs">#{req.id}</td>
                      <td className="font-mono font-medium text-slate-200">{req.user_identifier}</td>
                      <td>
                        {req.kind === 'deposit' ? (
                          <span className="text-emerald-400 font-bold text-xs">ငွေသွင်း</span>
                        ) : (
                          <span className="text-amber-400 font-bold text-xs">ငွေထုတ်</span>
                        )}
                      </td>
                      <td className="font-mono font-bold text-white">
                        {req.amount.toLocaleString()} MMK
                      </td>
                      <td>{req.payment_method}</td>
                      <td className="font-mono text-xs">
                        <div className="font-bold text-emerald-300">{req.txn_id || '—'}</div>
                        <div className="text-[11px] text-slate-400">{req.account_number} ({req.account_name})</div>
                      </td>
                      <td>
                        {req.execution_type === 'auto' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                            <Zap className="w-3 h-3 fill-amber-300" /> Auto
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400">Manual</span>
                        )}
                      </td>
                      <td>
                        {req.status === 'approved' && (
                          <span className="status approved">
                            {req.kind === 'withdrawal' && req.execution_type === 'auto'
                              ? 'Auto Disbursed'
                              : 'အတည်ပြုပြီး'}
                          </span>
                        )}
                        {req.status === 'rejected' && <span className="status rejected">ပယ်ချခဲ့သည်</span>}
                        {req.status === 'pending' && <span className="status">စောင့်ဆိုင်းဆဲ</span>}
                      </td>
                      <td className="text-slate-400 text-xs">{req.created_at}</td>
                      <td>
                        {req.status === 'pending' ? (
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleApprove(req.id)}
                              className="button small py-1 px-2.5 text-xs font-bold"
                              title="အတည်ပြုပြီး MMK ဖြည့်သွင်း/လွှဲပေးမည်"
                            >
                              <Check className="w-3.5 h-3.5 mr-1" /> အတည်ပြု
                            </button>
                            <button
                              onClick={() => handleReject(req.id)}
                              className="button small danger py-1 px-2.5 text-xs"
                              title="ပယ်ချမည်"
                            >
                              <X className="w-3.5 h-3.5 mr-1" /> ပယ်ချ
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400 italic">
                            {req.auto_checked ? 'Auto Verified' : 'ပြီးစီးပါပြီ'}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Tab 2: Gateway Vaults */}
      {adminTab === 'gateway' && (
        <section className="panel space-y-6 border-emerald-500/25">
          <div className="border-b border-white/10 pb-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-400" /> Auto-Withdrawal Gateway Disbursement Vaults
            </h2>
            <p className="text-xs text-slate-300">
              အသုံးပြုသူများ ငွေထုတ်ယူသည့်အခါ အလိုအလျောက် ငွေလွှဲပေးပို့ရန် အသုံးပြုသော Gateway Account လက်ကျန်ငွေများ။
            </p>
          </div>

          <div className="grid gap-4">
            {Object.values(gatewayWallets).map((gw) => (
              <div
                key={gw.code}
                className="p-5 rounded-xl border border-white/10 bg-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <strong className="text-white text-base">{gw.name}</strong>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      ● Live Connected
                    </span>
                  </div>
                  <div className="text-sm font-mono text-emerald-400">
                    Disbursement ဖုန်းနံပါတ်: <strong>{gw.phone}</strong>
                  </div>
                  <div className="text-xs text-slate-400">
                    စုစုပေါင်း အလိုအလျောက် ထုတ်ပေးငွေ: <strong>{gw.total_disbursed.toLocaleString()} MMK</strong>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Gateway လက်ကျန်ငွေ:</span>
                  <strong className="text-2xl font-black text-emerald-300 font-mono">
                    {gw.balance.toLocaleString()} MMK
                  </strong>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Tab 3: Users */}
      {adminTab === 'users' && (
        <section className="panel wide border-emerald-500/25 space-y-6">
          <div className="border-b border-white/10 pb-4">
            <h2 className="text-xl font-bold text-white">အသုံးပြုသူများ စာရင်း</h2>
            <p className="text-xs text-slate-300">
              အသင်းဝင်များ၏ အချက်အလက်၊ လက်ရှိ MMK လက်ကျန်နှင့် အခြေအနေ။
            </p>
          </div>

          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>အမှတ်စဉ်</th>
                  <th>ဖုန်းနံပါတ် / Email</th>
                  <th>အဆင့်</th>
                  <th>MMK လက်ကျန်ငွေ</th>
                  <th>အခြေအနေ</th>
                  <th>အသင်းဝင်သည့်ရက်</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="font-mono text-xs">#{u.id}</td>
                    <td className="font-mono font-medium text-white">{u.login_identifier}</td>
                    <td>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${u.role === 'admin' ? 'bg-amber-500/20 text-amber-300' : 'bg-white/5 text-slate-300'}`}>
                        {u.role === 'admin' ? 'စီမံခန့်ခွဲသူ' : 'အသင်းဝင်'}
                      </span>
                    </td>
                    <td className="font-mono font-bold text-emerald-400 text-sm">
                      {u.wallet_balance.toLocaleString()} MMK
                    </td>
                    <td>
                      <span className="status approved">တက်ကြွသည် (Active)</span>
                    </td>
                    <td className="text-slate-400 text-xs">{u.created_at}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Tab 4: Payment Providers */}
      {adminTab === 'providers' && (
        <section className="panel space-y-6 border-emerald-500/25">
          <div className="border-b border-white/10 pb-4">
            <h2 className="text-xl font-bold text-white">ငွေပေးချေမှု ပလက်ဖောင်း ဆက်တင်များ</h2>
            <p className="text-xs text-slate-300">
              အသုံးပြုသူများ ငွေလွှဲပေးသွင်းရမည့် KBZPay, WavePay ငွေလက်ခံဖုန်းနံပါတ်နှင့် အမည်များကို ပြင်ဆင်နိုင်သည်။
            </p>
          </div>

          {editingProvider ? (
            <form onSubmit={handleSaveProvider} className="form max-w-lg p-5 rounded-xl bg-black/40 border border-emerald-500/30">
              <h3 className="text-lg font-bold text-white mb-2">{editingProvider.name} အကောင့် ပြင်ဆင်ရန်</h3>

              <div className="field">
                <label>ငွေလက်ခံ ဖုန်းနံပါတ်</label>
                <input
                  type="text"
                  value={editingProvider.receiver_phone}
                  onChange={(e) => setEditingProvider({ ...editingProvider, receiver_phone: e.target.value })}
                  required
                />
              </div>

              <div className="field">
                <label>ငွေလက်ခံ အကောင့်အမည်</label>
                <input
                  type="text"
                  value={editingProvider.receiver_name}
                  onChange={(e) => setEditingProvider({ ...editingProvider, receiver_name: e.target.value })}
                  required
                />
              </div>

              <div className="flex gap-2 mt-4">
                <button type="submit" className="button">
                  သိမ်းဆည်းမည်
                </button>
                <button
                  type="button"
                  onClick={() => setEditingProvider(null)}
                  className="button secondary"
                >
                  မလုပ်တော့ပါ
                </button>
              </div>
            </form>
          ) : (
            <div className="grid gap-4">
              {providers.map((p) => (
                <div
                  key={p.code}
                  className="p-5 rounded-xl border border-white/10 bg-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <strong className="text-white text-base">{p.name}</strong>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                        {p.status === 'active' ? 'အသုံးပြုနေသည်' : 'ပိတ်ထားသည်'}
                      </span>
                    </div>
                    <div className="text-sm font-mono text-emerald-400">
                      ငွေလက်ခံနံပါတ်: <strong>{p.receiver_phone}</strong>
                    </div>
                    <div className="text-xs text-slate-400">
                      အကောင့်အမည်: {p.receiver_name}
                    </div>
                  </div>

                  <button
                    onClick={() => setEditingProvider(p)}
                    className="button secondary small"
                  >
                    ဖုန်းနံပါတ်/အမည် ပြင်ဆင်မည်
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Tab 5: System Settings */}
      {adminTab === 'settings' && (
        <section className="panel space-y-5 border-emerald-500/25">
          <div className="border-b border-white/10 pb-4">
            <h2 className="text-xl font-bold text-white">စနစ်ဆိုင်ရာ ဆက်တင်များ</h2>
            <p className="text-xs text-slate-300">
              AzLottery MMK လုပ်ဆောင်မှုဆိုင်ရာ ကန့်သတ်ချက်များနှင့် စည်းမျဉ်းများ။
            </p>
          </div>

          <div className="space-y-4 text-xs text-slate-300">
            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
              <strong className="text-white text-sm block">ငွေကြေးနှင့် အလိုအလျောက် စနစ်</strong>
              <p>• တရားဝင် သုံးစွဲငွေကြေး: <strong>မြန်မာကျပ်ငွေ (MMK)</strong></p>
              <p>• Deposit Slip Check: <strong>{isAutoDepositCheckEnabled ? 'ဖွင့်ထားသည်' : 'ပိတ်ထားသည်'}</strong></p>
              <p>• Auto-Withdraw Disburse: <strong>{isAutoWithdrawEnabled ? 'ဖွင့်ထားသည်' : 'ပိတ်ထားသည်'}</strong></p>
              <p>• အနည်းဆုံး ငွေသွင်း/ငွေထုတ် ပမာဏ: <strong>၁,၀၀၀ MMK</strong></p>
            </div>

            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
              <strong className="text-white text-sm block">ဂိမ်းဆိုင်ရာ ကန့်သတ်ချက်များ</strong>
              <p>• WinGo အနည်းဆုံး/အများဆုံး လောင်းကြေး: <strong>၁၀၀ မှ ၅,၀၀၀ MMK</strong></p>
              <p>• ကံစမ်းဘီး အနည်းဆုံး/အများဆုံး လောင်းကြေး: <strong>၁၀၀ မှ ၅,၀၀၀ MMK</strong></p>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
