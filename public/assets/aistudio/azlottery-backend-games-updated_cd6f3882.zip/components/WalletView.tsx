'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import type { User, PaymentRequest, ProviderConnection, GatewayWallet } from '@/lib/store';
import { extractReceiptInfo, type ParsedReceipt } from '@/lib/receiptParser';
import {
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  Copy,
  Check,
  CheckCircle2,
  AlertCircle,
  Clock,
  ShieldCheck,
  Zap,
  FileCheck2,
  ScanText,
  Send,
  Building2,
} from 'lucide-react';

interface WalletViewProps {
  currentUser: User;
  initialTab?: 'deposit' | 'withdraw';
  requests: PaymentRequest[];
  providers: ProviderConnection[];
  gatewayWallets: Record<string, GatewayWallet>;
  isAutoWithdrawEnabled: boolean;
  isAutoDepositCheckEnabled: boolean;
  onResetBalanceToZero?: () => void;
  onCreateDeposit: (
    amountMMK: number,
    paymentMethod: string,
    accountNumber: string,
    accountName: string,
    txnInputOrSlipText: string,
    note?: string
  ) => { autoApproved: boolean; trxId: string; amount: number; message: string };
  onCreateWithdrawal: (
    amountMMK: number,
    paymentMethod: string,
    accountNumber: string,
    accountName: string,
    note?: string
  ) => { autoDisbursed: boolean; trxId?: string; disbursedFrom?: string; amount: number; message: string };
}

export const WalletView: React.FC<WalletViewProps> = ({
  currentUser,
  initialTab = 'deposit',
  requests,
  providers,
  gatewayWallets,
  isAutoWithdrawEnabled,
  isAutoDepositCheckEnabled,
  onResetBalanceToZero,
  onCreateDeposit,
  onCreateWithdrawal,
}) => {
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>(initialTab);
  const [selectedProvider, setSelectedProvider] = useState<string>('kbz');
  const [copied, setCopied] = useState<boolean>(false);

  // Deposit Form State
  const [depAmount, setDepAmount] = useState<number>(10000);
  const [depSenderPhone, setDepSenderPhone] = useState<string>(currentUser.login_identifier || '');
  const [depSenderName, setDepSenderName] = useState<string>('Ko Aung');
  const [depTxnId, setDepTxnId] = useState<string>('');
  const [depSlipText, setDepSlipText] = useState<string>('');
  const [parsedPreview, setParsedPreview] = useState<ParsedReceipt | null>(null);
  const [depNote, setDepNote] = useState<string>('');
  const [depResult, setDepResult] = useState<{ autoApproved: boolean; message: string; trxId: string } | null>(null);
  const [depError, setDepError] = useState<string | null>(null);

  // Withdraw Form State
  const [wdAmount, setWdAmount] = useState<number>(10000);
  const [wdPhone, setWdPhone] = useState<string>(currentUser.login_identifier || '');
  const [wdName, setWdName] = useState<string>('Ko Aung');
  const [wdNote, setWdNote] = useState<string>('');
  const [wdResult, setWdResult] = useState<{ autoDisbursed: boolean; message: string; trxId?: string; disbursedFrom?: string } | null>(null);
  const [wdError, setWdError] = useState<string | null>(null);

  const currentProviderObj = providers.find((p) => p.code === selectedProvider) || providers[0];
  const activeGwWallet = gatewayWallets[selectedProvider] || gatewayWallets.kbz;

  const handleCopyReceiver = () => {
    navigator.clipboard.writeText(currentProviderObj.receiver_phone);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Live slip parser test
  const handleParseSlip = (text: string) => {
    setDepSlipText(text);
    if (!text.trim()) {
      setParsedPreview(null);
      return;
    }
    const info = extractReceiptInfo(text, depSenderPhone);
    setParsedPreview(info);
    if (info.trx_id && !depTxnId) {
      setDepTxnId(info.trx_id);
    }
    if (info.extracted_amount && info.extracted_amount >= 1000) {
      setDepAmount(info.extracted_amount);
    }
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDepError(null);
    setDepResult(null);

    const inputData = depSlipText.trim() || depTxnId.trim();

    if (!inputData) {
      setDepError('လုပ်ဆောင်ချက် အမှတ်စဉ် (TXN ID) သို့မဟုတ် ပြေစာ စာသားကို ထည့်သွင်းပေးပါ။');
      return;
    }

    if (depAmount < 1000 || depAmount > 1000000) {
      setDepError('ငွေသွင်းပမာဏသည် ၁,၀၀၀ မှ ၁,၀၀၀,၀၀၀ MMK အတွင်း ဖြစ်ရပါမည်။');
      return;
    }

    try {
      const res = onCreateDeposit(
        depAmount,
        currentProviderObj.name,
        depSenderPhone,
        depSenderName,
        inputData,
        depNote
      );
      setDepResult({
        autoApproved: res.autoApproved,
        message: res.message,
        trxId: res.trxId,
      });
      setDepTxnId('');
      setDepSlipText('');
      setParsedPreview(null);
    } catch (err: any) {
      setDepError(err.message || 'ငွေသွင်းတောင်းဆိုမှု မအောင်မြင်ပါ။');
    }
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWdError(null);
    setWdResult(null);

    if (wdAmount < 1000 || wdAmount > 1000000) {
      setWdError('ငွေထုတ်ပမာဏသည် ၁,၀၀၀ မှ ၁,၀၀၀,၀၀၀ MMK အတွင်း ဖြစ်ရပါမည်။');
      return;
    }

    if (currentUser.wallet_balance < wdAmount) {
      setWdError('ထုတ်ယူရန် MMK လက်ကျန်ငွေ မလုံလောက်ပါ။');
      return;
    }

    try {
      const res = onCreateWithdrawal(wdAmount, currentProviderObj.name, wdPhone, wdName, wdNote);
      setWdResult({
        autoDisbursed: res.autoDisbursed,
        message: res.message,
        trxId: res.trxId,
        disbursedFrom: res.disbursedFrom,
      });
    } catch (err: any) {
      setWdError(err.message || 'ငွေထုတ်တောင်းဆိုမှု မအောင်မြင်ပါ။');
    }
  };

  const myRequests = requests.filter((r) => r.user_id === currentUser.id);

  return (
    <div className="space-y-8 animate-in fade-in">
      {/* Header & Balance Display */}
      <div className="section-head">
        <div>
          <span className="eyebrow flex items-center gap-1.5 text-emerald-400">
            <Zap className="w-3.5 h-3.5 fill-emerald-400" /> Auto-Payment & Deposit Check စနစ်ပါဝင်သော ပိုက်ဆံအိတ်
          </span>
          <h1 className="text-3xl font-extrabold text-white">ပိုက်ဆံအိတ်နှင့် ငွေသွင်း/ငွေထုတ်</h1>
          <p className="text-sm text-slate-300">
            ပြေစာစစ်ဆေးမှု (Receipt OCR Check) ဖြင့် အလိုအလျောက် ငွေသွင်းစစ်ဆေးခြင်းနှင့် Auto-Withdraw ဖြင့် စက္ကန့်ပိုင်းအတွင်း ငွေလွှဲထုတ်ယူနိုင်ပါသည်။
          </p>
        </div>
      </div>

      {/* Large Balance Banner */}
      <div className="panel bg-gradient-to-br from-[#0c2317] to-[#07150e] border-emerald-500/35 p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
        <div>
          <span className="text-xs uppercase tracking-wider text-emerald-400 font-bold block mb-1">
            ရရှိနိုင်သော MMK လက်ကျန်ငွေ (Available Balance)
          </span>
          <strong className="text-3xl sm:text-5xl font-black text-emerald-300 font-mono tracking-tight">
            {currentUser.wallet_balance.toLocaleString()} MMK
          </strong>
          <div className="flex items-center gap-2 mt-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              <Zap className="w-3 h-3 fill-emerald-400" /> Auto-Withdraw: {isAutoWithdrawEnabled ? 'ဖွင့်ထားသည် (Active)' : 'ပိတ်ထားသည်'}
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
              <FileCheck2 className="w-3 h-3" /> Auto Deposit Check: {isAutoDepositCheckEnabled ? 'ဖွင့်ထားသည် (Active)' : 'ပိတ်ထားသည်'}
            </span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('deposit')}
            className={`button flex-1 sm:flex-initial flex items-center justify-center gap-1.5 ${activeTab === 'deposit' ? '' : 'secondary'}`}
          >
            <ArrowDownCircle className="w-4 h-4" /> ငွေသွင်းရန် (Deposit)
          </button>
          <button
            onClick={() => setActiveTab('withdraw')}
            className={`button flex-1 sm:flex-initial flex items-center justify-center gap-1.5 ${activeTab === 'withdraw' ? '' : 'secondary'}`}
          >
            <ArrowUpCircle className="w-4 h-4" /> ငွေထုတ်ရန် (Auto Withdraw)
          </button>
          {onResetBalanceToZero && currentUser.wallet_balance > 0 && (
            <button
              onClick={onResetBalanceToZero}
              className="button small secondary text-xs text-slate-400 hover:text-amber-300"
              title="စစ်မှန်သော 0 MMK သို့ ပြန်လည်ရှင်းလင်းရန်"
            >
              0 MMK သို့ရှင်းမည်
            </button>
          )}
        </div>
      </div>

      {/* Genuine Zero Balance Alert */}
      {currentUser.wallet_balance === 0 && (
        <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-emerald-200 text-xs sm:text-sm shadow-md">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>
              သင့်အကောင့်တွင် လက်ကျန်ငွေ <strong>0 MMK</strong> ဖြစ်နေပါသည်။ ဆက်လက်ကစားရန် KBZPay (သို့) WavePay ပြေစာဖြင့် ငွေသွင်း စစ်ဆေးနိုင်ပါသည်။
            </span>
          </div>
          <button
            onClick={() => setActiveTab('deposit')}
            className="button small shrink-0 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold"
          >
            ငွေစတင်သွင်းမည်
          </button>
        </div>
      )}

      {/* Tabs / Actions */}
      <div className="two-col">
        {/* Left Side: Deposit or Withdraw Form */}
        <div className="panel border-emerald-500/25">
          {activeTab === 'deposit' ? (
            <div className="space-y-5">
              <div className="border-b border-white/10 pb-3 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <ArrowDownCircle className="w-5 h-5 text-emerald-400" /> ငွေသွင်းခြင်းနှင့် ပြေစာစစ်ဆေးမှု
                  </h2>
                  <p className="text-xs text-slate-300">
                    ငွေလွှဲပြေစာ သို့မဟုတ် TXN ID ကို ထည့်သွင်းစစ်ဆေးပြီး အလိုအလျောက် ငွေလက်ခံနိုင်ပါသည်။
                  </p>
                </div>
                <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  ⚡ Auto Check
                </span>
              </div>

              {/* Provider Selection */}
              <div className="field">
                <label className="text-slate-700 font-bold">ငွေလွှဲမည့် ပလက်ဖောင်း ရွေးပါ</label>
                <div className="grid grid-cols-3 gap-2.5">
                  {providers.map((p) => {
                    const isSelected = selectedProvider === p.code;
                    return (
                      <button
                        key={p.code}
                        type="button"
                        onClick={() => setSelectedProvider(p.code)}
                        className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                          isSelected
                            ? 'border-[#4782ff] bg-blue-50/80 text-blue-900 font-extrabold shadow-xs ring-2 ring-blue-500/20'
                            : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <div className="relative w-8 h-8">
                          {p.code === 'kbz' ? (
                            <Image
                              src="/cklottery/png/kbz_icon-j2UvitJy.png"
                              alt="KBZPay"
                              fill
                              className="object-contain"
                              referrerPolicy="no-referrer"
                            />
                          ) : p.code === 'wave' ? (
                            <Image
                              src="/cklottery/png/wave_icon-MMSgjjJE.png"
                              alt="WavePay"
                              fill
                              className="object-contain"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-red-600 text-white font-black text-xs flex items-center justify-center">
                              AYA
                            </div>
                          )}
                        </div>
                        <span className="block text-xs font-bold leading-tight">{p.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Official Receiver Card */}
              <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200/80 space-y-1.5">
                <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider block">
                  ငွေလက်ခံမည့် {currentProviderObj.name} အကောင့်
                </span>
                <div className="flex items-center justify-between">
                  <div>
                    <strong className="text-slate-900 text-base sm:text-lg font-mono block">
                      {currentProviderObj.receiver_phone}
                    </strong>
                    <span className="text-xs text-slate-500 font-medium">အမည်: {currentProviderObj.receiver_name}</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyReceiver}
                    className="button small secondary flex items-center gap-1 text-xs bg-white text-[#4782ff] border-blue-200"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'ကူးပြီး' : 'နံပါတ်ကူးမည်'}</span>
                  </button>
                </div>
              </div>

              <form onSubmit={handleDepositSubmit} className="form">
                <div className="field">
                  <label htmlFor="dep-amount">ငွေသွင်းမည့် ပမာဏ (MMK)</label>
                  <input
                    id="dep-amount"
                    type="number"
                    min="1000"
                    max="1000000"
                    step="500"
                    value={depAmount}
                    onChange={(e) => setDepAmount(Number(e.target.value))}
                    required
                  />

                  {/* Quick Amount Chips */}
                  <div className="flex flex-wrap gap-2 mt-1">
                    {[5000, 10000, 20000, 50000, 100000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setDepAmount(amt)}
                        className={`button small ${depAmount === amt ? '' : 'secondary text-xs py-1'}`}
                      >
                        {amt.toLocaleString()} MMK
                      </button>
                    ))}
                  </div>
                </div>

                <div className="field">
                  <label htmlFor="dep-sender">ငွေလွှဲသူ ဖုန်းနံပါတ် / အကောင့်အမှတ်</label>
                  <input
                    id="dep-sender"
                    type="text"
                    value={depSenderPhone}
                    onChange={(e) => setDepSenderPhone(e.target.value)}
                    placeholder="09..."
                    required
                  />
                </div>

                {/* Slip text / OCR paste */}
                <div className="field">
                  <label htmlFor="dep-slip" className="flex items-center justify-between">
                    <span>ပြေစာ စာသား (Slip OCR Text / Paste)</span>
                    <span className="text-[10px] text-emerald-400 font-bold">Smart Auto-Detect</span>
                  </label>
                  <textarea
                    id="dep-slip"
                    rows={2}
                    value={depSlipText}
                    onChange={(e) => handleParseSlip(e.target.value)}
                    placeholder="WavePay / KBZPay ပြေစာ စာသား ကူးယူထည့်သွင်းပါက TXN ID နှင့် ပမာဏကို အလိုအလျောက် ရှာဖွေပေးပါမည်…"
                    className="text-xs font-mono"
                  />
                </div>

                <div className="field">
                  <label htmlFor="dep-txnid">လုပ်ဆောင်ချက် အမှတ်စဉ် (TXN ID / Order No)</label>
                  <input
                    id="dep-txnid"
                    type="text"
                    value={depTxnId}
                    onChange={(e) => setDepTxnId(e.target.value)}
                    placeholder="ဥပမာ 987654321012 သို့မဟုတ် 020261024..."
                    required
                  />
                </div>

                {/* Parsed Preview Badge */}
                {parsedPreview && parsedPreview.trx_id && (
                  <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-300 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-emerald-200">
                      <ScanText className="w-4 h-4" /> စလစ်စစ်ဆေးတွေ့ရှိချက်:
                    </div>
                    <div className="font-mono text-[11px] space-y-0.5">
                      <div>• TXN ID: <strong className="text-white">{parsedPreview.trx_id}</strong> (နောက်ဆုံး: {parsedPreview.last5_digits})</div>
                      {parsedPreview.extracted_amount && (
                        <div>• စလစ်ရှိငွေပမာဏ: <strong className="text-amber-300">{parsedPreview.extracted_amount.toLocaleString()} MMK</strong></div>
                      )}
                      <div>• Provider: <strong>{parsedPreview.provider.toUpperCase()}</strong></div>
                    </div>
                  </div>
                )}

                {depError && (
                  <div className="p-3 bg-red-500/20 border border-red-500/30 rounded-xl text-xs text-red-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{depError}</span>
                  </div>
                )}

                {depResult && (
                  <div className="p-4 bg-emerald-500/20 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-sm text-emerald-200">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      <span>{depResult.autoApproved ? 'အလိုအလျောက် စစ်ဆေးအတည်ပြုပြီး (Auto-Verified)!' : 'တောင်းဆိုမှု လက်ခံရရှိပါသည်'}</span>
                    </div>
                    <p className="text-slate-200">{depResult.message}</p>
                    <div className="font-mono text-[11px] text-emerald-400 pt-1 border-t border-emerald-500/20">
                      TXN Reference: #{depResult.trxId}
                    </div>
                  </div>
                )}

                <button type="submit" className="button w-full py-3.5 text-base font-extrabold flex items-center justify-center gap-2">
                  <Zap className="w-4 h-4 fill-black" />
                  <span>{depAmount.toLocaleString()} MMK စစ်ဆေးပြီး ငွေသွင်းမည် (Auto Check)</span>
                </button>
              </form>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="border-b border-white/10 pb-3 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <ArrowUpCircle className="w-5 h-5 text-amber-400" /> အလိုအလျောက် ငွေထုတ်ယူခြင်း (Auto-Withdraw)
                  </h2>
                  <p className="text-xs text-slate-300">
                    သင့် WavePay သို့မဟုတ် KBZPay သို့ စက္ကန့်ပိုင်းအတွင်း အလိုအလျောက် လွှဲပြောင်းပေးပါမည်။
                  </p>
                </div>
                <span className="text-[11px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30 flex items-center gap-1">
                  <Zap className="w-3 h-3 fill-amber-300" /> Instant Payout
                </span>
              </div>

              {/* Provider Selection */}
              <div className="field">
                <label className="text-slate-700 font-bold">ငွေထုတ်ယူမည့် စနစ် ရွေးပါ</label>
                <div className="grid grid-cols-3 gap-2.5">
                  {providers.map((p) => {
                    const isSelected = selectedProvider === p.code;
                    return (
                      <button
                        key={p.code}
                        type="button"
                        onClick={() => setSelectedProvider(p.code)}
                        className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                          isSelected
                            ? 'border-[#4782ff] bg-blue-50/80 text-blue-900 font-extrabold shadow-xs ring-2 ring-blue-500/20'
                            : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <div className="relative w-8 h-8">
                          {p.code === 'kbz' ? (
                            <Image
                              src="/cklottery/png/kbz_icon-j2UvitJy.png"
                              alt="KBZPay"
                              fill
                              className="object-contain"
                              referrerPolicy="no-referrer"
                            />
                          ) : p.code === 'wave' ? (
                            <Image
                              src="/cklottery/png/wave_icon-MMSgjjJE.png"
                              alt="WavePay"
                              fill
                              className="object-contain"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-red-600 text-white font-black text-xs flex items-center justify-center">
                              AYA
                            </div>
                          )}
                        </div>
                        <span className="block text-xs font-bold leading-tight">{p.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Gateway Live Vault Indicator */}
              <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-emerald-400" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">Disbursement Gateway Vault:</span>
                    <strong className="text-white">{activeGwWallet.name}</strong>
                  </div>
                </div>
                <div className="text-right font-mono">
                  <span className="text-[10px] text-emerald-400 font-bold block">● Live Connected</span>
                  <span className="text-slate-300 text-[11px]">ကျန်ငွေ: {activeGwWallet.balance.toLocaleString()} MMK</span>
                </div>
              </div>

              <form onSubmit={handleWithdrawSubmit} className="form">
                <div className="field">
                  <label htmlFor="wd-amount">ထုတ်ယူမည့် ပမာဏ (MMK)</label>
                  <input
                    id="wd-amount"
                    type="number"
                    min="1000"
                    max={currentUser.wallet_balance}
                    step="500"
                    value={wdAmount}
                    onChange={(e) => setWdAmount(Number(e.target.value))}
                    required
                  />

                  {/* Quick percentage buttons */}
                  <div className="flex flex-wrap gap-2 mt-1">
                    {[10000, 20000, 50000, currentUser.wallet_balance].map((amt, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setWdAmount(Math.min(currentUser.wallet_balance, amt))}
                        className="button small secondary text-xs py-1"
                      >
                        {idx === 3 ? 'အားလုံးထုတ်မည်' : `${amt.toLocaleString()} MMK`}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="field">
                  <label htmlFor="wd-phone">သင့် {currentProviderObj.name} ဖုန်းနံပါတ်</label>
                  <input
                    id="wd-phone"
                    type="text"
                    value={wdPhone}
                    onChange={(e) => setWdPhone(e.target.value)}
                    placeholder="09..."
                    required
                  />
                </div>

                <div className="field">
                  <label htmlFor="wd-name">အကောင့်ပိုင်ရှင် အမည်</label>
                  <input
                    id="wd-name"
                    type="text"
                    value={wdName}
                    onChange={(e) => setWdName(e.target.value)}
                    placeholder="သင့်အမည်"
                    required
                  />
                </div>

                {wdError && (
                  <div className="p-3 bg-red-500/20 border border-red-500/30 rounded-xl text-xs text-red-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{wdError}</span>
                  </div>
                )}

                {wdResult && (
                  <div className="p-4 bg-emerald-500/20 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-sm text-emerald-200">
                      <Zap className="w-5 h-5 text-amber-400 fill-amber-400" />
                      <span>{wdResult.autoDisbursed ? 'Auto-Withdraw အောင်မြင်စွာ လွှဲပြောင်းပြီး!' : 'ငွေထုတ်တောင်းဆိုမှု လက်ခံရရှိပါသည်'}</span>
                    </div>
                    <p className="text-slate-200">{wdResult.message}</p>
                    {wdResult.trxId && (
                      <div className="font-mono text-[11px] text-amber-300 pt-1 border-t border-emerald-500/20 flex items-center justify-between">
                        <span>Gateway TXN ID: #{wdResult.trxId}</span>
                        <span>Disbursed From: {wdResult.disbursedFrom}</span>
                      </div>
                    )}
                  </div>
                )}

                <button type="submit" className="button w-full py-3.5 text-base font-extrabold flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-emerald-500 text-black">
                  <Send className="w-4 h-4 fill-black" />
                  <span>{wdAmount.toLocaleString()} MMK အလိုအလျောက် ထုတ်ယူမည် (Instant Withdraw)</span>
                </button>
              </form>
            </div>
          )}
        </div>

        {/* Right Side: Security & Processing Information */}
        <div className="space-y-4">
          <section className="panel space-y-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" /> Decr-main Auto Payment စနစ် လုပ်ဆောင်ချက်
            </h2>
            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <strong className="text-white block text-sm flex items-center gap-1.5">
                  <FileCheck2 className="w-4 h-4 text-emerald-400" /> Deposit Slip Check (ငွေသွင်းစစ်ဆေးမှု):
                </strong>
                <p>• WavePay နှင့် KBZPay ပြေစာများရှိ Myanmar ဂဏန်းများ (၀-၉) နှင့် Transaction ID များကို အလိုအလျောက် စစ်ဆေးဖတ်ယူသည်။</p>
                <p>• ပြေစာနံပါတ် တူညီမှုမရှိစေရန် (Anti Double-Spending) စစ်ဆေးပြီး အတည်ပြုပါက MMK ချက်ချင်း ဝင်ရောက်ပါသည်။</p>
              </div>

              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <strong className="text-white block text-sm flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-amber-400 fill-amber-400" /> Auto-Withdraw (အလိုအလျောက် ငွေလွှဲထုတ်ပေးမှု):
                </strong>
                <p>• အသုံးပြုသူ ငွေထုတ်ယူသည့်အခါ Gateway Server Wallet မှတစ်ဆင့် သင့် WavePay/KBZPay ဖုန်းသို့ စက္ကန့်ပိုင်းအတွင်း အလိုအလျောက် ငွေလွှဲပေးပို့ပါသည်။</p>
                <p>• စနစ်မှ တရားဝင် Transaction ID ကို ချက်ချင်း ထုတ်ပေးပြီး စာရင်းရှင်းလင်းပေးပါသည်။</p>
              </div>

              <div className="p-3 bg-emerald-950/20 border border-emerald-500/20 rounded-xl text-emerald-300 text-[11px]">
                💡 Admin Panel သို့ သွားရောက်၍ Auto-Withdraw ဖွင့်/ပိတ် switch နှင့် Gateway Vault လက်ကျန်ငွေများကို စစ်ဆေးထိန်းချုပ်နိုင်ပါသည်။
              </div>
            </div>
          </section>

          {/* Quick Gateway Balances Summary */}
          <div className="panel bg-white/5 p-4 space-y-2">
            <span className="text-xs font-bold text-slate-300 block">Active Gateway Disbursement Vaults:</span>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="p-2.5 rounded-lg bg-black/40 border border-white/5">
                <span className="text-[10px] text-yellow-400 block font-sans">WavePay Vault</span>
                <strong className="text-white text-sm">{(gatewayWallets.wave?.balance || 0).toLocaleString()} MMK</strong>
              </div>
              <div className="p-2.5 rounded-lg bg-black/40 border border-white/5">
                <span className="text-[10px] text-blue-400 block font-sans">KBZPay Vault</span>
                <strong className="text-white text-sm">{(gatewayWallets.kbz?.balance || 0).toLocaleString()} MMK</strong>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Requests History Table */}
      <section className="section">
        <div className="section-head">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-emerald-400" /> သင့် ငွေသွင်း/ငွေထုတ် တောင်းဆိုမှုမှတ်တမ်း
            </h2>
            <p className="text-xs text-slate-300">
              အလိုအလျောက် စစ်ဆေးပြီးစီးမှုနှင့် Auto-Disburse လွှဲပြောင်းမှု အခြေအနေများ။
            </p>
          </div>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>အမျိုးအစား</th>
                <th>ပမာဏ</th>
                <th>စနစ်</th>
                <th>အကောင့်အမှတ်စဉ်</th>
                <th>TXN ID</th>
                <th>လုပ်ဆောင်မှုပုံစံ</th>
                <th>အခြေအနေ</th>
                <th>ရက်စွဲ</th>
              </tr>
            </thead>
            <tbody>
              {myRequests.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-6 text-slate-400">
                    ငွေသွင်း/ငွေထုတ် တောင်းဆိုမှုမှတ်တမ်း မရှိသေးပါ။
                  </td>
                </tr>
              ) : (
                myRequests.map((req) => (
                  <tr key={req.id}>
                    <td>
                      {req.kind === 'deposit' ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1">
                          <ArrowDownCircle className="w-3.5 h-3.5" /> ငွေသွင်း
                        </span>
                      ) : (
                        <span className="text-amber-400 font-bold flex items-center gap-1">
                          <ArrowUpCircle className="w-3.5 h-3.5" /> ငွေထုတ်
                        </span>
                      )}
                    </td>
                    <td className="font-mono font-bold text-white">
                      {req.amount.toLocaleString()} MMK
                    </td>
                    <td>{req.payment_method}</td>
                    <td className="font-mono text-xs">{req.account_number}</td>
                    <td className="font-mono text-xs text-emerald-300 font-semibold">{req.txn_id || '—'}</td>
                    <td>
                      {req.execution_type === 'auto' ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                          <Zap className="w-3 h-3 fill-amber-300" /> Auto
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400">Manual</span>
                      )}
                    </td>
                    <td>
                      {req.status === 'approved' && (
                        <span className="status approved">
                          {req.kind === 'withdrawal' && req.execution_type === 'auto'
                            ? 'Auto Disbursed'
                            : 'အတည်ပြုပြီး'}
                        </span>
                      )}
                      {req.status === 'rejected' && <span className="status rejected">ပယ်ချခဲ့သည်</span>}
                      {req.status === 'pending' && <span className="status">စောင့်ဆိုင်းဆဲ</span>}
                    </td>
                    <td className="text-slate-400 text-xs">{req.created_at}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
