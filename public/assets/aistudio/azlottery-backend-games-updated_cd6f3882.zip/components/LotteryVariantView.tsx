'use client';
import React, { useCallback, useEffect, useState } from 'react';
import Image from 'next/image';
import { ArrowLeft, Clock3, HelpCircle, RefreshCw, Volume2, VolumeX } from 'lucide-react';
import type { User } from '@/lib/store';

type Variant = 'k3' | '5d' | 'trx';
type Config = { label: string; subtitle: string; periods: number[]; options: string[]; icon: string };
type GameState = { balance: number; current: { periodId: string; secondsLeft: number; result: string | null; bettingOpen: boolean }; history: { periodId: string; result: string | null }[] };
const CONFIG: Record<Variant, Config> = {
  k3: { label: 'K3', subtitle: 'Three dice · Big / Small / Odd / Even', periods: [1, 3, 5, 10], options: ['Big', 'Small', 'Odd', 'Even'], icon: '/cklottery/lotterycategory/k3.png' },
  '5d': { label: '5D', subtitle: 'Five digits · Big / Small / Odd / Even', periods: [1, 3, 5, 10], options: ['Big', 'Small', 'Odd', 'Even'], icon: '/cklottery/lotterycategory/5d.png' },
  trx: { label: 'TRX Win', subtitle: 'Blockchain-style result · Color / Size', periods: [1, 3, 5, 10], options: ['Green', 'Red', 'Big', 'Small'], icon: '/cklottery/lotterycategory/trx-win.png' },
};

export const LotteryVariantView: React.FC<{ variant: Variant; currentUser: User; onNavigate: (tab: string) => void }> = ({ variant, currentUser, onNavigate }) => {
  const config = CONFIG[variant];
  const [periodMinutes, setPeriodMinutes] = useState(config.periods[0]);
  const [secondsLeft, setSecondsLeft] = useState(config.periods[0] * 60);
  const [balance, setBalance] = useState(currentUser.wallet_balance);
  const [currentResult, setCurrentResult] = useState<string | null>(null);
  const [history, setHistory] = useState<GameState['history']>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [sound, setSound] = useState(true);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState('Loading game state…');

  const loadState = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/games/${variant}/state?interval=${periodMinutes}`, { credentials: 'same-origin', cache: 'no-store' });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Game state unavailable');
      const state = data as GameState;
      setBalance(state.balance);
      setSecondsLeft(state.current.secondsLeft);
      setCurrentResult(state.current.result);
      setHistory(state.history || []);
      setNotice('Backend round connected · wallet ledger enabled');
    } catch (error) {
      setNotice(error instanceof Error ? error.message : 'Game state unavailable');
    } finally { setLoading(false); }
  }, [periodMinutes, variant]);

  useEffect(() => { const initial = window.setTimeout(() => void loadState(), 0); const timer = window.setInterval(() => void loadState(), 5000); return () => { window.clearTimeout(initial); window.clearInterval(timer); }; }, [loadState]);
  useEffect(() => { const timer = window.setInterval(() => setSecondsLeft((value) => value <= 0 ? 0 : value - 1), 1000); return () => window.clearInterval(timer); }, []);

  const confirm = async () => {
    if (!selected) { setNotice('Choose a play option first'); return; }
    setLoading(true);
    try {
      const response = await fetch(`/api/games/${variant}/bet`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ interval: periodMinutes, selection: selected, stake: 100, idempotencyKey: crypto.randomUUID() }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Bet could not be placed');
      setBalance(Number(data.balance));
      setSelected(null);
      setNotice(`Bet accepted for ${data.bet.periodId}. Settlement is server-controlled.`);
      void loadState();
    } catch (error) { setNotice(error instanceof Error ? error.message : 'Bet could not be placed'); }
    finally { setLoading(false); }
  };
  const minutes = Math.floor(secondsLeft / 60).toString().padStart(2, '0');
  const seconds = (secondsLeft % 60).toString().padStart(2, '0');
  const displayResult = currentResult || (loading ? '···' : 'Pending');

  return <div className="variant-shell">
    <header className="variant-header"><button type="button" onClick={() => onNavigate('home')} aria-label="Back"><ArrowLeft /></button><div><strong>{config.label}</strong><small>{config.subtitle}</small></div><button type="button" onClick={() => setSound((value) => !value)} aria-label="Toggle sound">{sound ? <Volume2 /> : <VolumeX />}</button></header>
    <section className="variant-balance-card"><span>Backend wallet balance</span><strong>K{balance.toLocaleString()} <small>MMK</small></strong><button type="button" onClick={() => onNavigate('wallet')}>Wallet</button></section>
    <div className="variant-periods" role="tablist" aria-label="Draw periods">{config.periods.map((period) => <button type="button" key={period} onClick={() => { setPeriodMinutes(period); setSecondsLeft(period * 60); setSelected(null); }} className={period === periodMinutes ? 'active' : ''}>{period} Min</button>)}</div>
    <section className="variant-ticket"><div className="variant-ticket-top"><span>Server period</span><span><Clock3 /> {minutes}:{seconds}</span></div><Image src={config.icon} alt="" width={54} height={54} /><strong>{displayResult}</strong><small>{currentResult ? 'Settled result' : 'Waiting for server result'}</small></section>
    <section className="variant-history"><div className="variant-section-title"><h2>Server results</h2><button type="button" onClick={() => void loadState()} disabled={loading}><RefreshCw /> Refresh</button></div><div className="variant-result-list">{history.map((item, index) => <span key={`${item.periodId}-${index}`}>{item.result || 'Pending'}</span>)}</div></section>
    <section className="variant-bet-card"><div className="variant-section-title"><h2>Choose your play</h2><HelpCircle /></div><div className="variant-options">{config.options.map((option) => <button type="button" key={option} onClick={() => setSelected(option)} className={selected === option ? 'selected' : ''}>{option}</button>)}</div><div className="variant-stake-row"><span>Stake</span><strong>100 MMK</strong></div><button type="button" className="variant-confirm" onClick={() => void confirm()} disabled={loading || secondsLeft <= 5}> {loading ? 'Connecting…' : 'Confirm bet'} </button><p className="variant-notice">{notice}</p></section>
    <p className="variant-disclaimer">Results, bets, balance debits, and payouts are now controlled by the AzLottery backend database. Deposits and withdrawals remain in the existing wallet flow.</p>
  </div>;
};
