'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Volume2, ChevronRight, Sparkles, Trophy, Flame, Gamepad2 } from 'lucide-react';
import type { User } from '@/lib/store';

interface HomeViewProps {
  currentUser: User;
  onNavigate: (tab: string) => void;
}

const categories = [
  { id: 'popular', title: 'Popular', image: '/cklottery/png/popular-8_UUQbeo.png', style: 'category-popular' },
  { id: 'lottery', title: 'Lottery', image: '/cklottery/png/lottery-Dbl-eMPh.png', style: 'category-lottery' },
  { id: 'slot', title: 'Slots', image: '/cklottery/png/slot-DM52Kkhg.png', style: 'category-slots' },
  { id: 'sport', title: 'Sports', image: '/cklottery/png/sport-CFnl9BGk.png', style: 'category-sports' },
  { id: 'casino', title: 'Casino', image: '/cklottery/png/video-CepDEnWM.png', style: 'category-casino' },
  { id: 'rummy', title: 'Rummy', image: '/cklottery/png/chess-Dg5bPKcx.png', style: 'category-rummy' },
  { id: 'fish', title: 'Fishing', image: '/cklottery/png/fish-D0liGLFa.png', style: 'category-fishing' },
  { id: 'original', title: 'Original', image: '/cklottery/png/superjackpotHome-BSFlrooL.png', style: 'category-original' },
];

const providers = [
  { name: 'PP GAME', image: '/cklottery/png/popular-8_UUQbeo.png', action: 'games' },
  { name: 'JILI GAME', image: '/cklottery/png/slot-DM52Kkhg.png', action: 'games' },
  { name: 'CQ9 GAME', image: '/cklottery/png/fish-D0liGLFa.png', action: 'games' },
  { name: 'MG GAME', image: '/cklottery/png/sport-CFnl9BGk.png', action: 'games' },
  { name: 'JDB GAME', image: '/cklottery/png/chess-Dg5bPKcx.png', action: 'games' },
  { name: 'G9 GAME', image: '/cklottery/png/video-CepDEnWM.png', action: 'games' },
];

const lotteryGames = [
  { name: 'Win Go', description: 'Guess Number', detail: 'Green/Red/Violet to win', image: '/cklottery/lotterycategory/win-go.png', action: 'wingo', featured: true },
  { name: 'K3', description: 'Three dice', detail: 'Big/Small/Odd/Even · Practice', image: '/cklottery/lotterycategory/k3.png', action: 'k3' },
  { name: '5D', description: 'Five digits', detail: 'Big/Small/Odd/Even · Practice', image: '/cklottery/lotterycategory/5d.png', action: '5d' },
  { name: 'Trx Win', description: 'Hash-style result', detail: 'Color/Size · Practice', image: '/cklottery/lotterycategory/trx-win.png', action: 'trx' },
];

const banners = [
  { image: '/cklottery/png/banner-wccltQJr.png', alt: 'AzLottery promotions' },
  { image: '/cklottery/png/MyCoinsBanner-DdbMZNYq.png', alt: 'Rewards and coins' },
  { image: '/cklottery/png/superjackpotHome-BSFlrooL.png', alt: 'Super jackpot' },
];

export const HomeView: React.FC<HomeViewProps> = ({ currentUser, onNavigate }) => {
  const [activeBanner, setActiveBanner] = useState(0);
  const [activeCategory, setActiveCategory] = useState('popular');

  return (
    <div className="lobby-page">
      <section className="lobby-banner" aria-label="Promotions">
        <Image src={banners[activeBanner].image} alt={banners[activeBanner].alt} fill priority sizes="(max-width: 480px) 100vw, 480px" className="lobby-banner-image" />
        <div className="lobby-banner-dots" aria-label="Select promotion">
          {banners.map((banner, index) => (
            <button key={banner.image} type="button" onClick={() => setActiveBanner(index)} className={activeBanner === index ? 'active' : ''} aria-label={`Promotion ${index + 1}`} />
          ))}
        </div>
      </section>

      <button type="button" className="lobby-notice" onClick={() => onNavigate('promotion')}>
        <span className="lobby-notice-icon"><Volume2 size={16} /></span>
        <span className="lobby-notice-copy">ဝန်ဆောင်မှုနှင့် ငွေသွင်းဆိုင်ရာ နောက်ဆုံးကြေညာချက်များ</span>
        <ChevronRight size={17} className="lobby-notice-arrow" />
      </button>

      <section className="lobby-category-section" aria-label="Game categories">
        <div className="lobby-category-grid">
          {categories.map((category) => (
            <button
              key={category.id}
              type="button"
              onClick={() => {
                setActiveCategory(category.id);
                if (category.id === 'lottery') {
                  document.getElementById('lobby-lottery-games')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                } else {
                  onNavigate('games');
                }
              }}
              className={`lobby-category ${category.style} ${activeCategory === category.id ? 'selected' : ''}`}
            >
              <Image src={category.image} alt="" fill sizes="150px" className="lobby-category-image" />
              <span>{category.title}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="lobby-providers" aria-label="Featured games">
        <div className="lobby-section-heading">
          <h2><span className="lobby-heading-mark"><Gamepad2 size={15} /></span> Slots</h2>
          <button type="button" onClick={() => onNavigate('games')}>More <ChevronRight size={14} /></button>
        </div>
        <div className="lobby-provider-grid">
          {providers.map((provider, index) => (
            <button type="button" key={provider.name} className={`lobby-provider provider-${index + 1}`} onClick={() => onNavigate(provider.action)}>
              <span className="lobby-provider-name">{provider.name}</span>
              <span className="lobby-provider-art">
                <Image src={provider.image} alt="" fill sizes="140px" className="lobby-provider-image" />
              </span>
            </button>
          ))}
        </div>
      </section>

      <section className="lobby-lottery-section" id="lobby-lottery-games" aria-label="Lottery games">
        <div className="lobby-section-heading">
          <h2><span className="lobby-heading-mark"><Sparkles size={14} /></span> Lottery</h2>
          <button type="button" onClick={() => onNavigate('games')}>More <ChevronRight size={14} /></button>
        </div>
        <div className="lobby-lottery-grid">
          {lotteryGames.map((game) => (
            <button type="button" key={game.name} className={`lobby-lottery-card ${game.featured ? 'featured' : ''}`} onClick={() => onNavigate(game.action)}>
              <span className="lobby-lottery-copy">
                <strong>{game.name}</strong>
                <small>{game.description}</small>
                <small>{game.detail}</small>
              </span>
              <span className="lobby-lottery-art">
                <Image src={game.image} alt={`${game.name} lottery game`} fill sizes="120px" className="lobby-lottery-image" />
              </span>
            </button>
          ))}
        </div>
      </section>

      <section className="lobby-winners">
        <div className="lobby-section-heading">
          <h2><span className="lobby-heading-mark winner-mark"><Trophy size={14} /></span> Winning information</h2>
          <button type="button" onClick={() => onNavigate('transactions')}>More <ChevronRight size={14} /></button>
        </div>
        <div className="lobby-winner-row">
          <span className="lobby-winner-avatar"><Sparkles size={15} /></span>
          <span className="lobby-winner-label">Today&apos;s earnings chart</span>
          <span className="lobby-winner-amount"><Flame size={13} /> K{currentUser.wallet_balance.toLocaleString()}</span>
        </div>
      </section>

      <div className="lobby-bottom-space" />
    </div>
  );
};
